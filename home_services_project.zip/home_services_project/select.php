
<?php
include "dbconfigure.php";
$categoryname = $_REQUEST['cat'];
$query3 = "select * from category where categoryname='$categoryname'";
$rs3=my_select($query3);
$categoryid = "";
if($row3=mysqli_fetch_array($rs3))
{
 $categoryid=$row3[0];
}

?>
<?php
include"dbconfig.php";
$result=select("select city from country_state_city");
$result1=select("select * from subcategory where categoryid=$categoryid");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Service City</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Amatic+SC:400,700|Work+Sans:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/mediaelement@4.2.7/build/mediaelementplayer.min.css">
    
    
    
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
  
    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
    
  </head>
  <body>
  
  <div class="site-wrap">

    <div class="site-mobile-menu">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div> <!-- .site-mobile-menu -->
    
      <?php include"nav.php"?>
  
  
    <div style="height: 113px;"></div>

    <div class="unit-5 overlay" style="background-image: url('images/hero_1.jpg');">
      <div class="container text-center">
        <form  action="new.php" method="post" class="p-5  form-inline">

              
              <div class="row form-group">
                <div class="col-lg-12" style="margin-left:160px">
				 <input type="hidden" value="<?php echo $categoryid; ?>" name="category" >
              
                <select class="form-control " name="city">
				<option>Select Your City                   </option>
				<?php
while($r=mysqli_fetch_array($result))
{
	
?>
<option value="<?=$r[0]?>"><?=$r[0]?></option>
<?php

}
?>
	</select>
	
	<select class="form-control " name="subcategory">
				<option>Select SubCategory</option>
				<?php
while($r=mysqli_fetch_array($result1))
{
	
?>
<option value="<?=$r[0]?>"><?=$r[2]?></option>
<?php

}
?>
	</select>
	
	
	
               <input type="submit" value="Search" name="okay" class="btn btn-primary pill px-4 py-2">
               </div>
             

              

              
</div>
  
            </form>
    </div>
    </div>

    
    
    


    


    
   <?php include"footer1.php";?>
  
  </div>

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/aos.js"></script>

  
  <script src="js/mediaelement-and-player.min.js"></script>

  <script src="js/main.js"></script>
    

  
  </body>
</html>