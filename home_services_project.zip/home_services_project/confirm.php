<?php
//index.php
include"dbconfig.php";

$query1 = "SELECT * FROM registration where id=".$_SESSION['id']."";
$query = "SELECT * FROM booking where reg_id=".$_SESSION['id']."";
$result = select($query);
$result1 = select($query1);




?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Service City</title>

  <link href="https://fonts.googleapis.com/css?family=Amatic+SC:400,700|Work+Sans:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/mediaelement@4.2.7/build/mediaelementplayer.min.css">
    
    
    
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
  
    <link rel="stylesheet" href="css/aos.css">
  <link rel="stylesheet" href="css/style1.css">
  <link rel="stylesheet" href="css/style.css">
</head>

<style>

body{
  background-color: #f3f3f3;
}

</style>
<body>
<?php include "nav2.php"?>
  <!-- contact1 -->

  <?php
	//include"dbconfig.php";
	$r=mysqli_fetch_assoc($result);
	?>
  
  <section class="w3l-simple-contact-form1">
    <div class="contact-form section-gap">
      <div class="wrapper">
        <div class="text-center p-5">
        <h1 style="font-size: 40px; ">Confirm Booking</h1>
      </div>
        <div class="contact-form" style="max-width: 600px; margin: 0 auto;">
          <div class="form-mid">
            <form action="javascript:sendmail()" method="post">
              <div class="field">
              <input type="text" class="form-control" name="Name" id="Name"
                   placeholder="Service Providers Name" 
                   pattern="[A-Za-z -]{1,25}" title="Must contains characters from A-Z/a-z"
                   required>
              </div>
              <div class="field">
              <input type="text" class="form-control" name="Sender" id="Sender"
                   placeholder="Customer's Email" 
                   pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$"
                  title="Must be a valid email address with characters followed by an @ sign (example@characters.domain)"
                   required>
              </div>
              <div class="field">
                <input type="text" class="form-control" name="Subject" id="Subject" value="Booking Confirmed" readonly>
              </div>
              <textarea name="Message" class="form-control" id="Message"
              readonly>Dear customer, your booking has been confirmed. Service provider will soon reach at your location.</textarea> <br/>
             <center> <button type="submit" class="btn btn-info">Send Message</button></center>
              <!-- <input type="button" class="btn btn-contact" onclick="sendmail();"  value="Send Message"> -->

            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- /contact1 -->
  
<!-- <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script> -->
<script
  src="https://code.jquery.com/jquery-2.2.4.min.js"
  integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="
  crossorigin="anonymous">
</script>
<script src="https://smtpjs.com/v3/smtp.js"></script>
 
  <script>  

     function sendmail(){
    
			var name = $('#Name').val();
			var email = $('#Sender').val();
			var subject = $('#Subject').val();
      var message = $('#Message').val();

			// var body = $('#body').val();

			var Body='Name: '+name+'<br>Subject: '+subject+'<br>Message: '+message;
			//console.log(name, phone, email, message);

			Email.send({

        SecureToken:"fbf31702-bb7f-4a4e-9c1c-4ccf17ee777f",
				To: email,
				From: "servicecity.notification@gmail.com",
				Subject: "New message from service provider "+name,
				Body: Body
			}).then(
				message =>{
					//console.log (message);
					if(message=='OK'){
					alert('Your mail has been send. Thank you for connecting.');
					}
					else{
						console.error (message);
						alert('There is error at sending message. ')
						
					}

				}
			);



		}


  </script>

<?php
	?>

  <?php include "footer1.php"?>
</body>
</html>