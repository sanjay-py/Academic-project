<!DOCTYPE html>
<html>
<head>
<style>
footer {
  text-align: center;
  padding: 3px;
  background-color: black;
  color: white;
}
</style>
</head>
<body>
<div class="py-5 quick-contact-info" style="background-color:white";>
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <div>
              <h2><span class="icon-room"></span> Location</h2>
              <p class="mb-0">Belgaum <br>  Karnataka</p>
            </div>
          </div>
          <div class="col-md-4">
            <div>
              <h2><span class="icon-clock-o"></span> Service Times</h2>
              <p class="mb-0">Monday to saturday at 8AM - 7:30PM <br>
              Sunday holiday <br>
              </p>
            </div>
          </div>
          <div class="col-md-4">
            <h2><span class="icon-comments"></span> Get In Touch</h2>
            <p class="mb-0">Email: servicecity.notification@gmail.com <br>
            Phone: +91 7259330026 </p>
          </div>
        </div>
      </div>
    </div>
<footer>
<div class="col-md-12">
            <p style = "font-size : 15pt ; color : #fff ;">

            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All Rights Reserved
                <span style = "color : 	#3cb371">|</span>
                <span style = "color : 	#d2691e">Service City </span>

            </p>
          </div>
</footer>

</body>
</html>