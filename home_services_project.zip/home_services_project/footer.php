
<div class="py-5 quick-contact-info">
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <div>
              <h2><span class="icon-room"></span> Location</h2>
              <p class="mb-0">Belgaum <br>  Karnataka</p>
            </div>
          </div>
          <div class="col-md-4">
            <div>
              <h2><span class="icon-clock-o"></span> Service Times</h2>
              <p class="mb-0">Monday to saturday at 8AM - 7:30PM <br>
              Sunday holiday <br>
              </p>
            </div>
          </div>
          <div class="col-md-4">
            <h2><span class="icon-comments"></span> Get In Touch</h2>
            <p class="mb-0">Email: servicecity.notification@gmail.com <br>
            Phone: +91 7259330026 </p>
          </div>
        </div>
      </div>
    </div>

</style>
 <footer class="site-footer" style="height: 20px;">
      <div class="container">
        
        <div class="row text-center">
          <div class="col-md-12">
            <p style = "font-size : 15pt ; color : #FF0000 ; font-weight : bold">

            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All Rights Reserved
                <span style = "color : brown">|</span>
                <span style = "color : #006400">Service City </span>

            </p>
          </div>
          
        </div>
      </div>
    </footer>