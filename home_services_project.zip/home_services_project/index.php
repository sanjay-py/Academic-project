<?php include "dbconfigure.php"; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Service City</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Amatic+SC:400,700|Work+Sans:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/mediaelement@4.2.7/build/mediaelementplayer.min.css">
    
    
    
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
  
    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
    <style>
body{
  background-color: #f3f3f3;
 
  background-size: cover;

}
      </style>
  </head>
  <body >
  
  <div class="site-wrap">

    <div class="site-mobile-menu">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div> <!-- .site-mobile-menu -->
    
    
    <?php include "nav.php"?>
  
    <div style="height: 113px;"></div>

    <div class="site-blocks-cover overlay" style="background-image: url('images/hero_1.png');" data-aos="fade" data-stellar-background-ratio="0.5">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-12" data-aos="fade">
            <h1 style="font-weight:bold">Smart Way, Easy Life...</h1>
            <h3 style="color:white">Expert in Services. Repair. Maintenance.</h3>
            
          </div>
        </div>
      </div>
    </div>
    

    <div class="site-section">
      <div class="container">
        <div class="row">
          <div class="col-md-6 mx-auto text-center mb-5 section-heading">
            <h2 class="mb-5">POPULAR CATEGORIES</h2>
          </div>
        </div>
        <div class="row">
		<?php 
		$query123 = "select * from category";
		$rs123 = my_select($query123);
		while($row123 = mysqli_fetch_array($rs123))
		{
		?>
           <div class="col-sm-6 col-md-4 col-lg-3 mb-3" data-aos="fade-up" data-aos-delay="700">
             <a href="select.php?cat=<?php echo $row123[1];?>" class="h-100 feature-item">
 <img src="images/serviceman.png" style="width:80px"></br></br> <h2 style="font-weight:bold"><?php echo $row123[1] ?> </h2>
 
             <span class="counting"><?php totalelectrician($row123[0]); ?></span>
            </a>
          </div>
		  <?php
		  }
		  ?>
          

      </div>
    </div>


   

    


    <div class="site-blocks-cover overlay inner-page" style="background-image: url('images/ind.jpg');" data-aos="fade" data-stellar-background-ratio="0.5">
      <div class="container" >
        <div class="row align-items-center justify-content-center">
          <div class="col-md-6 text-center" data-aos="fade">
             <h1 style="font-weight:bold">Smart Way Easy Life...</h1>
            <h3 style="color:white">Expert in Serivce. Repair. Maintenance.</h3>
            
          </div>
        </div>
      </div>
    </div>

    

    

    


   


       
        <div class="row">
          
        </div>
      </div>
    </div>
    


    
   <?php include"footer1.php"; ?>
  </div>

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/aos.js"></script>

  
  <script src="js/mediaelement-and-player.min.js"></script>

  <script src="js/main.js"></script>
    

  






  </body>
</html>

<?php 

function totalelectrician($id)
{
$query = "select * from registration where work_type='$id'";
$rs = my_select($query);
$n = mysqli_num_rows($rs);
echo $n;
}


function totalplumber()
{
$query = "select * from category where categoryname='Plumber'";
$rs = my_select($query);
$n = mysqli_num_rows($rs);
return $n;
}

function totalcarpenter()
{
$query = "select * from category where categoryname='Carpenter'";
$rs = my_select($query);
$n = mysqli_num_rows($rs);
return $n;
}

function totalpainter()
{
$query = "select * from category where categoryname='Painter'";
$rs = my_select($query);
$n = mysqli_num_rows($rs);
return $n;
}

function totalmaid()
{
$query = "select * from category where categoryname='Maid'";
$rs = my_select($query);
$n = mysqli_num_rows($rs);
return $n;
}

function totalmechanic()
{
$query = "select * from category where categoryname='Mechanic'";
$rs = my_select($query);
$n = mysqli_num_rows($rs);
return $n;
}

function totalmoverandpacker()
{
$query = "select * from category where categoryname='Mover And Packer'";
$rs = my_select($query);
$n = mysqli_num_rows($rs);
return $n;
}


function totallaundry()
{
$query = "select * from category where categoryname='Laundry Man'";
$rs = my_select($query);
$n = mysqli_num_rows($rs);
return $n;
}

function totalwatersupplier()
{
$query = "select * from category where categoryname='Water Supplier'";
$rs = my_select($query);
$n = mysqli_num_rows($rs);
return $n;
}
?>