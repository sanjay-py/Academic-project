
<div class="site-navbar-wrap js-site-navbar bg-white">
      
      <div class="container">
        <div class="site-navbar bg-light">
          <div class="py-1">
            <div class="row align-items-center">
              <div class="col-2">
                <h2 class="mb-0 site-logo" ><a href="index.php"><strong class="font-weight-bold"> Service City</strong> </a></h2>
              </div>
              <div class="col-10">
                <nav class="site-navigation text-right" role="navigation">
                  <div class="container">
                    <div class="d-inline-block d-lg-none ml-md-0 mr-auto py-3"><a href="#" class="site-menu-toggle js-menu-toggle text-black"><span class="icon-menu h3"></span></a></div>

                    <ul class="site-menu js-clone-nav d-none d-lg-block">
					
	<li><a href="index.php">Home</a></li>				
					
					
                      <li><a href="registration.php">Registration</a></li>
                      <li><a href="login.php">Login</a></li> 
                      <!-- <li><a href="contact.php">Contact</a></li>                      -->
					            <li><a href="admin/index.php">Admin Login</a></li>
                      </ul>
                  </div>
                </nav>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

<!-- <style>
.site-navbar-wrap a:hover {
  color: #e74c3c;
}
.site-navbar-wrap a::before {
  content: "";
  transition: all 0.4s ease-in-out;
  position: absolute;
  right: 50%;
  left: 50%;
  bottom: 0;
  height: 2px;
  background-color: #e74c3c;
}
.site-navbar-wrap a:hover::before {
  right: 0;
  left: 0;
}
</style>    -->